(window.webpackJsonp=window.webpackJsonp||[]).push([[6],{268:function(t,e,a){"use strict";a.r(e),a.d(e,"addCssBlock",(function(){return d}));a(126),a(216),a(74),a(193),a(16);var n=a(186);const i=document.createElement("template");i.innerHTML=`<style>\n  ${n.a.cssText}\n  ${n.b.cssText}\n</style>`,document.head.appendChild(i.content);a(139),a(217),a(259),a(22),a(246),a(25),a(21),a(24),a(26);var o=a(116),l=(a(147),a(218),a(66),a(123),a(89),Object.defineProperty),r=Object.getOwnPropertyDescriptor;let s=class extends o.a{static get styles(){return o.b`
      :host {
          display: block;
          height: 100%;
      }
      `}render(){return o.d`
<vaadin-vertical-layout style="width: 100%; height: 100%;">
 <vaadin-horizontal-layout class="header" style="width: 100%; flex-basis: var(--lumo-size-l); flex-shrink: 0; background-color: var(--lumo-contrast-10pct); flex-grow: 0; flex-direction: row;">
  <img style="width: 10%; margin: var(--lumo-space-s); flex-shrink: 0; align-self: center;" src="img\logos\loginLogo.png">
  <vaadin-text-field placeholder="Поиск..." style="flex-shrink: 0; flex-grow: 1; align-self: center; margin: var(--lumo-space-s);" type="text">
   <iron-icon icon="lumo:search" slot="prefix"></iron-icon>
  </vaadin-text-field>
  <vaadin-icon id="vaadinIcon"></vaadin-icon>
 </vaadin-horizontal-layout>
 <vaadin-vertical-layout class="content" style="width: 100%; flex-grow: 1; flex-shrink: 1; flex-basis: auto;"></vaadin-vertical-layout>
 <vaadin-horizontal-layout class="footer" style="width: 100%; flex-basis: var(--lumo-size-l); flex-shrink: 0; background-color: var(--lumo-contrast-10pct);"></vaadin-horizontal-layout>
</vaadin-vertical-layout>
`}createRenderRoot(){return this}};s=((t,e,a,n)=>{for(var i,o=n>1?void 0:n?r(e,a):e,s=t.length-1;s>=0;s--)(i=t[s])&&(o=(n?i(e,a,o):i(o))||o);return n&&o&&l(e,a,o),o})([Object(o.c)("substrate-view")],s);const d=function(t,e=!1){const a=document.createElement("template");a.innerHTML=t,document.head[e?"insertBefore":"appendChild"](a.content,document.head.firstChild)};let c;const u=document.getElementsByTagName("script");for(let t=0;t<u.length;t++){const e=u[t];if("module"==e.getAttribute("type")&&e.getAttribute("data-app-id")&&!e["vaadin-bundle"]){c=e;break}}if(!c)throw new Error("Could not find the bundle script to identify the application id");c["vaadin-bundle"]=!0,window.Vaadin.Flow.fallbacks||(window.Vaadin.Flow.fallbacks={});const h=window.Vaadin.Flow.fallbacks;h[c.getAttribute("data-app-id")]={},h[c.getAttribute("data-app-id")].loadFallback=function(){return Promise.all([a.e(1),a.e(3)]).then(a.bind(null,267))}}}]);